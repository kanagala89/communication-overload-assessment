// Assessment Data
const assessmentData = {
  questions: [
    {
      id: 1,
      category: "Email Management",
      question: "How often do you feel overwhelmed by your email volume?",
      responses: ["Never", "Rarely", "Sometimes", "Often", "Daily"]
    },
    {
      id: 2,
      category: "Response Pressure", 
      question: "How pressured do you feel to respond to messages immediately?",
      responses: ["No pressure", "Slight pressure", "Moderate pressure", "High pressure", "Extreme pressure"]
    },
    {
      id: 3,
      category: "Meeting Fatigue",
      question: "How often do meetings prevent you from focused work?",
      responses: ["Never", "Rarely", "Sometimes", "Often", "Constantly"]
    },
    {
      id: 4,
      category: "Digital Distractions",
      question: "How frequently do notifications interrupt your deep work?",
      responses: ["Never", "Few times daily", "Hourly", "Every 30 minutes", "Every few minutes"]
    },
    {
      id: 5,
      category: "Channel Management",
      question: "How overwhelming is switching between communication platforms?",
      responses: ["Very easy", "Manageable", "Somewhat difficult", "Very difficult", "Extremely overwhelming"]
    },
    {
      id: 6,
      category: "Focus & Productivity",
      question: "How often can you work uninterrupted for 2+ hours?",
      responses: ["Daily", "Few times weekly", "Weekly", "Rarely", "Never"]
    },
    {
      id: 7,
      category: "Digital Wellbeing",
      question: "How burned out do you feel from digital communication?",
      responses: ["Not at all", "Slightly", "Moderately", "Very burned out", "Completely burned out"]
    },
    {
      id: 8,
      category: "Priority Management",
      question: "How difficult is it to identify urgent vs. important messages?",
      responses: ["Very easy", "Easy", "Moderate", "Difficult", "Nearly impossible"]
    },
    {
      id: 9,
      category: "Work-Life Balance",
      question: "How well do you maintain communication boundaries after hours?",
      responses: ["Excellent boundaries", "Good boundaries", "Some boundaries", "Poor boundaries", "No boundaries"]
    },
    {
      id: 10,
      category: "Communication Efficiency",
      question: "How satisfied are you with your communication workflow?",
      responses: ["Very satisfied", "Satisfied", "Neutral", "Dissatisfied", "Completely dissatisfied"]
    }
  ],
  scoringCategories: {
    healthy: {min: 0, max: 30, color: "#22c55e", description: "Healthy Communication Habits"},
    moderate: {min: 31, max: 60, color: "#f59e0b", description: "Moderate Communication Overload"},
    severe: {min: 61, max: 100, color: "#ef4444", description: "Severe Communication Overload"}
  },
  recommendations: {
    email: [
      "Set specific times for checking email (e.g., 9am, 1pm, 4pm)",
      "Use email filters and folders to organize incoming messages",
      "Unsubscribe from unnecessary mailing lists",
      "Implement the 2-minute rule: if it takes less than 2 minutes, do it now"
    ],
    meetings: [
      "Block calendar time for focused work",
      "Question the necessity of each meeting invitation",
      "Suggest async alternatives when possible",
      "Set meeting-free time blocks daily"
    ],
    notifications: [
      "Turn off non-essential notifications during focus time",
      "Use Do Not Disturb modes effectively",
      "Batch process messages rather than responding immediately",
      "Create notification schedules that align with your work patterns"
    ],
    focus: [
      "Practice the Pomodoro Technique for sustained focus",
      "Create a dedicated workspace free from distractions",
      "Use noise-canceling headphones during deep work",
      "Communicate your availability clearly to colleagues"
    ]
  }
};

// App State
let currentState = {
  currentQuestion: 0,
  responses: {},
  totalQuestions: assessmentData.questions.length,
  currentTheme: 'light'
};

// Feedback messages based on response level
const feedbackMessages = {
  1: ["Great! 😊", "That's excellent!", "You're doing well! ✨"],
  2: ["Not bad! 👍", "That's manageable", "Good balance! ⚖️"],
  3: ["Moderate level 📊", "Room for improvement", "Consider some changes 🤔"],
  4: ["That's concerning 😟", "High stress level", "Time for action! ⚡"],
  5: ["Very high stress! 🚨", "Urgent attention needed", "Major changes required! 🔄"]
};

// DOM Elements
const elements = {
  landing: document.getElementById('landing'),
  assessment: document.getElementById('assessment'),
  results: document.getElementById('results'),
  startBtn: document.getElementById('startAssessment'),
  themeToggle: document.getElementById('themeToggle'),
  progressFill: document.getElementById('progressFill'),
  progressText: document.getElementById('progressText'),
  progressPercent: document.getElementById('progressPercent'),
  questionCategory: document.getElementById('questionCategory'),
  questionTitle: document.getElementById('questionTitle'),
  responseSlider: document.getElementById('responseSlider'),
  sliderStart: document.getElementById('sliderStart'),
  sliderEnd: document.getElementById('sliderEnd'),
  currentResponse: document.getElementById('currentResponse'),
  questionFeedback: document.getElementById('questionFeedback'),
  prevBtn: document.getElementById('prevBtn'),
  nextBtn: document.getElementById('nextBtn'),
  currentScore: document.getElementById('currentScore'),
  currentStatus: document.getElementById('currentStatus'),
  finalScore: document.getElementById('finalScore'),
  finalStatus: document.getElementById('finalStatus'),
  finalDescription: document.getElementById('finalDescription'),
  categoryScores: document.getElementById('categoryScores'),
  recommendationsList: document.getElementById('recommendationsList'),
  shareResults: document.getElementById('shareResults'),
  printResults: document.getElementById('printResults'),
  retakeAssessment: document.getElementById('retakeAssessment')
};

// Initialize App
document.addEventListener('DOMContentLoaded', function() {
  initializeTheme();
  attachEventListeners();
  updateCurrentScore();
});

// Theme Management
function initializeTheme() {
  const savedTheme = localStorage.getItem('theme') || 'light';
  currentState.currentTheme = savedTheme;
  applyTheme(savedTheme);
}

function applyTheme(theme) {
  document.documentElement.setAttribute('data-color-scheme', theme);
  const themeIcon = document.querySelector('.theme-icon');
  themeIcon.textContent = theme === 'dark' ? '☀️' : '🌙';
  localStorage.setItem('theme', theme);
}

function toggleTheme() {
  const newTheme = currentState.currentTheme === 'light' ? 'dark' : 'light';
  currentState.currentTheme = newTheme;
  applyTheme(newTheme);
}

// Event Listeners
function attachEventListeners() {
  elements.startBtn.addEventListener('click', startAssessment);
  elements.themeToggle.addEventListener('click', toggleTheme);
  elements.responseSlider.addEventListener('input', handleSliderChange);
  elements.prevBtn.addEventListener('click', previousQuestion);
  elements.nextBtn.addEventListener('click', nextQuestion);
  elements.shareResults.addEventListener('click', shareResults);
  elements.printResults.addEventListener('click', printResults);
  elements.retakeAssessment.addEventListener('click', retakeAssessment);
}

// Assessment Flow
function startAssessment() {
  elements.landing.classList.add('hidden');
  elements.assessment.classList.remove('hidden');
  elements.assessment.classList.add('fade-in-up');
  
  // Reset state
  currentState.currentQuestion = 0;
  currentState.responses = {};
  
  displayQuestion();
}

function displayQuestion() {
  const question = assessmentData.questions[currentState.currentQuestion];
  const questionNumber = currentState.currentQuestion + 1;
  
  // Update progress
  const progressPercentage = (questionNumber / currentState.totalQuestions) * 100;
  elements.progressFill.style.width = `${progressPercentage}%`;
  elements.progressText.textContent = `Question ${questionNumber} of ${currentState.totalQuestions}`;
  elements.progressPercent.textContent = `${Math.round(progressPercentage)}%`;
  
  // Update question content
  elements.questionCategory.textContent = question.category;
  elements.questionTitle.textContent = question.question;
  elements.sliderStart.textContent = question.responses[0];
  elements.sliderEnd.textContent = question.responses[4];
  
  // Set slider value
  const savedResponse = currentState.responses[question.id] || 3;
  elements.responseSlider.value = savedResponse;
  updateCurrentResponse(savedResponse, question.responses);
  
  // Update navigation buttons
  elements.prevBtn.disabled = currentState.currentQuestion === 0;
  elements.nextBtn.textContent = currentState.currentQuestion === currentState.totalQuestions - 1 ? 'View Results →' : 'Next →';
  
  // Update current score
  updateCurrentScore();
}

function handleSliderChange(event) {
  const value = parseInt(event.target.value);
  const question = assessmentData.questions[currentState.currentQuestion];
  
  // Save response
  currentState.responses[question.id] = value;
  
  // Update UI
  updateCurrentResponse(value, question.responses);
  showFeedback(value);
  updateCurrentScore();
}

function updateCurrentResponse(value, responses) {
  const responseText = responses[value - 1];
  elements.currentResponse.textContent = responseText;
  
  // Add color coding based on severity
  elements.currentResponse.className = 'current-response';
  if (value <= 2) {
    elements.currentResponse.style.background = 'rgba(34, 197, 94, 0.1)';
    elements.currentResponse.style.color = '#22c55e';
  } else if (value <= 3) {
    elements.currentResponse.style.background = 'rgba(245, 158, 11, 0.1)';
    elements.currentResponse.style.color = '#f59e0b';
  } else {
    elements.currentResponse.style.background = 'rgba(239, 68, 68, 0.1)';
    elements.currentResponse.style.color = '#ef4444';
  }
}

function showFeedback(value) {
  const messages = feedbackMessages[value];
  const randomMessage = messages[Math.floor(Math.random() * messages.length)];
  
  elements.questionFeedback.textContent = randomMessage;
  elements.questionFeedback.className = 'question-feedback show';
  
  // Color code feedback
  if (value <= 2) {
    elements.questionFeedback.style.background = 'rgba(34, 197, 94, 0.1)';
    elements.questionFeedback.style.color = '#22c55e';
  } else if (value <= 3) {
    elements.questionFeedback.style.background = 'rgba(245, 158, 11, 0.1)';
    elements.questionFeedback.style.color = '#f59e0b';
  } else {
    elements.questionFeedback.style.background = 'rgba(239, 68, 68, 0.1)';
    elements.questionFeedback.style.color = '#ef4444';
  }
  
  // Hide feedback after delay
  setTimeout(() => {
    elements.questionFeedback.classList.remove('show');
  }, 3000);
}

function previousQuestion() {
  if (currentState.currentQuestion > 0) {
    currentState.currentQuestion--;
    displayQuestion();
  }
}

function nextQuestion() {
  if (currentState.currentQuestion < currentState.totalQuestions - 1) {
    currentState.currentQuestion++;
    displayQuestion();
  } else {
    showResults();
  }
}

// Score Calculation
function calculateScore() {
  const responses = Object.values(currentState.responses);
  const totalScore = responses.reduce((sum, score) => sum + score, 0);
  const maxPossibleScore = currentState.totalQuestions * 5;
  const percentageScore = Math.round((totalScore / maxPossibleScore) * 100);
  
  return {
    raw: totalScore,
    percentage: percentageScore,
    maxPossible: maxPossibleScore
  };
}

function getScoreCategory(percentage) {
  const categories = assessmentData.scoringCategories;
  
  if (percentage <= categories.healthy.max) {
    return categories.healthy;
  } else if (percentage <= categories.moderate.max) {
    return categories.moderate;
  } else {
    return categories.severe;
  }
}

function updateCurrentScore() {
  const score = calculateScore();
  const category = getScoreCategory(score.percentage);
  
  elements.currentScore.textContent = score.percentage;
  elements.currentScore.style.color = category.color;
  elements.currentStatus.textContent = category.description;
  elements.currentStatus.style.color = category.color;
}

// Results Display
function showResults() {
  elements.assessment.classList.add('hidden');
  elements.results.classList.remove('hidden');
  elements.results.classList.add('fade-in-up');
  
  const score = calculateScore();
  const category = getScoreCategory(score.percentage);
  
  // Update overall score
  elements.finalScore.textContent = score.percentage;
  elements.finalScore.style.color = category.color;
  elements.finalStatus.textContent = category.description;
  elements.finalStatus.style.color = category.color;
  elements.finalDescription.textContent = getScoreDescription(score.percentage);
  
  // Display category breakdown
  displayCategoryBreakdown();
  
  // Display recommendations
  displayRecommendations(score.percentage);
}

function getScoreDescription(percentage) {
  if (percentage <= 30) {
    return "Excellent! You have healthy communication habits and good boundaries. Keep up the great work!";
  } else if (percentage <= 60) {
    return "You're experiencing moderate communication overload. Some adjustments could significantly improve your well-being.";
  } else {
    return "You're experiencing severe communication overload. It's time to take action to protect your mental health and productivity.";
  }
}

function displayCategoryBreakdown() {
  const categoryMap = {
    "Email Management": [],
    "Response Pressure": [],
    "Meeting Fatigue": [],
    "Digital Distractions": [],
    "Channel Management": [],
    "Focus & Productivity": [],
    "Digital Wellbeing": [],
    "Priority Management": [],
    "Work-Life Balance": [],
    "Communication Efficiency": []
  };
  
  // Group questions by category
  assessmentData.questions.forEach(question => {
    const response = currentState.responses[question.id] || 3;
    if (!categoryMap[question.category]) {
      categoryMap[question.category] = [];
    }
    categoryMap[question.category].push(response);
  });
  
  // Calculate average for each category and display
  let html = '';
  Object.entries(categoryMap).forEach(([category, scores]) => {
    if (scores.length > 0) {
      const average = scores.reduce((sum, score) => sum + score, 0) / scores.length;
      const percentage = Math.round((average / 5) * 100);
      const color = getScoreCategory(percentage).color;
      
      html += `
        <div class="category-score">
          <span class="category-score__name">${category}</span>
          <span class="category-score__value" style="background-color: ${color}">
            ${percentage}%
          </span>
        </div>
      `;
    }
  });
  
  elements.categoryScores.innerHTML = html;
}

function displayRecommendations(percentage) {
  let recommendations = [];
  
  // Add recommendations based on score and specific problem areas
  if (percentage > 60) {
    recommendations = [
      ...assessmentData.recommendations.email.slice(0, 2),
      ...assessmentData.recommendations.meetings.slice(0, 2),
      ...assessmentData.recommendations.notifications.slice(0, 2),
      ...assessmentData.recommendations.focus.slice(0, 2)
    ];
  } else if (percentage > 30) {
    recommendations = [
      ...assessmentData.recommendations.email.slice(0, 1),
      ...assessmentData.recommendations.meetings.slice(0, 1),
      ...assessmentData.recommendations.notifications.slice(0, 1),
      ...assessmentData.recommendations.focus.slice(0, 1)
    ];
  } else {
    recommendations = [
      "Continue your excellent communication habits!",
      "Consider sharing your strategies with colleagues",
      "Regular assessment helps maintain good habits"
    ];
  }
  
  const icons = ["💡", "🎯", "⚡", "🔧", "📋", "🎨", "🚀", "✨"];
  
  let html = '';
  recommendations.forEach((rec, index) => {
    const icon = icons[index % icons.length];
    html += `
      <div class="recommendation">
        <span class="recommendation__icon">${icon}</span>
        <span class="recommendation__text">${rec}</span>
      </div>
    `;
  });
  
  elements.recommendationsList.innerHTML = html;
}

// Action Handlers
function shareResults() {
  const score = calculateScore();
  const shareText = `I just completed a Communication Overload Assessment and scored ${score.percentage}%. Take the assessment yourself to see how digital communication affects your productivity! #CommunicationOverload #Productivity`;
  
  if (navigator.share) {
    navigator.share({
      title: 'Communication Overload Assessment Results',
      text: shareText,
      url: window.location.href
    });
  } else {
    // Fallback to copying to clipboard
    navigator.clipboard.writeText(shareText).then(() => {
      showToast('Results copied to clipboard!');
    }).catch(() => {
      showToast('Share feature not available');
    });
  }
}

function printResults() {
  window.print();
}

function retakeAssessment() {
  elements.results.classList.add('hidden');
  elements.landing.classList.remove('hidden');
  
  // Reset state
  currentState.currentQuestion = 0;
  currentState.responses = {};
  updateCurrentScore();
}

function showToast(message) {
  const toast = document.createElement('div');
  toast.textContent = message;
  toast.style.cssText = `
    position: fixed;
    top: 20px;
    right: 20px;
    background: var(--color-primary);
    color: var(--color-btn-primary-text);
    padding: 12px 24px;
    border-radius: 8px;
    z-index: 1000;
    font-weight: 500;
    box-shadow: var(--shadow-lg);
    transition: all 0.3s ease;
  `;
  
  document.body.appendChild(toast);
  
  setTimeout(() => {
    toast.style.opacity = '0';
    toast.style.transform = 'translateY(-20px)';
    setTimeout(() => {
      document.body.removeChild(toast);
    }, 300);
  }, 3000);
}

// Keyboard Navigation
document.addEventListener('keydown', function(event) {
  if (elements.assessment.classList.contains('hidden')) return;
  
  switch(event.key) {
    case 'ArrowLeft':
      if (!elements.prevBtn.disabled) {
        previousQuestion();
      }
      break;
    case 'ArrowRight':
    case 'Enter':
      nextQuestion();
      break;
    case '1':
    case '2':
    case '3':
    case '4':
    case '5':
      const value = parseInt(event.key);
      elements.responseSlider.value = value;
      handleSliderChange({target: {value: value}});
      break;
  }
});

// Add smooth scrolling for results
function smoothScrollToTop() {
  window.scrollTo({
    top: 0,
    behavior: 'smooth'
  });
}

// Auto-save progress (but inform user data isn't persistent)
function saveProgress() {
  const progressData = {
    currentQuestion: currentState.currentQuestion,
    responses: currentState.responses,
    timestamp: Date.now()
  };
  
  try {
    sessionStorage.setItem('assessmentProgress', JSON.stringify(progressData));
  } catch (error) {
    // Session storage not available, continue without saving
    console.log('Progress saving not available');
  }
}

function loadProgress() {
  try {
    const saved = sessionStorage.getItem('assessmentProgress');
    if (saved) {
      const progressData = JSON.parse(saved);
      // Only load if saved within last hour
      if (Date.now() - progressData.timestamp < 3600000) {
        currentState.currentQuestion = progressData.currentQuestion;
        currentState.responses = progressData.responses;
        return true;
      }
    }
  } catch (error) {
    // Continue without loading
    console.log('Progress loading not available');
  }
  return false;
}

// Save progress on each response
elements.responseSlider?.addEventListener('change', saveProgress);