# Communication Overload Assessment Tool

A modern, interactive web application that helps professionals identify communication overload patterns and provides personalized recommendations for improving digital wellbeing in the workplace.

## 🚀 Live Demo

Once deployed to GitHub Pages, your assessment tool will be available at:
`https://yourusername.github.io/communication-overload-assessment/`

## ✨ Features

### 📝 Interactive Assessment
- **10 Research-Based Questions**: Covering message volume, interruption frequency, response pressure, platform usage, and work-life balance
- **Real-Time Progress Tracking**: Visual progress bar and completion status
- **Mobile-Responsive Design**: Works seamlessly on desktop, tablet, and mobile devices

### 📊 Comprehensive Results
- **Personalized Scoring**: Overall assessment with severity levels (Healthy, Moderate Overload, Significant Overload)
- **Category Breakdown**: Detailed analysis across 10 communication dimensions
- **Actionable Recommendations**: Tailored advice based on individual response patterns

### 💡 Educational Content
- **Research-Based Insights**: Key statistics about communication overload in modern workplaces
- **Practical Tips**: Immediately implementable strategies for reducing digital overwhelm
- **Privacy-First**: All data processing happens locally in the user's browser

### 🛠️ Technical Features
- **Single-Page Application**: Tabbed interface with smooth transitions
- **Export Functionality**: Download results in JSON and text formats
- **Accessibility**: WCAG 2.1 compliant with keyboard navigation support
- **Dark Mode Support**: Automatic adaptation to user's system preferences

## 📁 Project Structure

```
communication-overload-assessment/
├── index.html          # Main application file
├── style.css           # Styling and responsive design
├── script.js           # Interactive functionality
└── README.md           # Documentation (this file)
```

## 🚀 Quick Deployment to GitHub Pages

### Method 1: Web Interface (Recommended)

1. **Create New Repository**
   - Go to [GitHub.com](https://github.com) and sign in
   - Click "+" → "New repository"
   - Name: `communication-overload-assessment`
   - Set to "Public"
   - Click "Create repository"

2. **Upload Files**
   - Click "uploading an existing file"
   - Drag and drop all 4 files (`index.html`, `style.css`, `script.js`, `README.md`)
   - Commit message: "Add communication overload assessment tool"
   - Click "Commit changes"

3. **Enable GitHub Pages**
   - Go to repository "Settings"
   - Scroll to "Pages" section
   - Source: "Deploy from a branch"
   - Branch: "main", Folder: "/ (root)"
   - Click "Save"

4. **Access Your Site**
   - Your tool will be live at: `https://yourusername.github.io/communication-overload-assessment/`
   - Deployment takes 5-10 minutes

### Method 2: Command Line

```bash
# Clone your repository
git clone https://github.com/yourusername/communication-overload-assessment.git
cd communication-overload-assessment

# Add files
cp /path/to/downloaded/files/* .

# Commit and push
git add .
git commit -m "Add communication overload assessment tool"
git push origin main
```

## 🎯 Assessment Categories

The tool evaluates communication overload across 10 key dimensions:

| Category | Description |
|----------|-------------|
| 📧 **Message Volume** | Daily quantity of work-related communications |
| 🔔 **Interruptions** | Frequency of notification-based work disruptions |
| ⚡ **Response Pressure** | Perceived urgency to reply immediately |
| 📱 **Platform Overload** | Number of communication tools used daily |
| 🗓️ **Meeting Load** | Time spent in meetings and video calls |
| 🎯 **Focus Impact** | Ability to maintain concentrated work periods |
| 😰 **Stress Level** | Emotional impact of communication demands |
| 🌙 **After-hours Work** | Communication outside business hours |
| 📈 **Productivity Impact** | Effect on task completion and quality |
| 🎛️ **Control Level** | Sense of agency over communication workload |

## 📊 Scoring System

- **Total Score Range**: 10-40 points
- **Healthy Balance**: 10-19 points - Well-managed communication habits
- **Moderate Overload**: 20-29 points - Some optimization needed
- **Significant Overload**: 30-40 points - Immediate intervention recommended

## 🛠️ Customization Options

### Adding Questions
Edit `script.js` and add new questions to the `assessmentQuestions` array:

```javascript
{
    id: 'q11',
    category: 'newCategory',
    question: 'Your new question here?',
    options: [
        { value: 1, text: 'Option 1' },
        { value: 2, text: 'Option 2' },
        { value: 3, text: 'Option 3' },
        { value: 4, text: 'Option 4' }
    ]
}
```

### Changing Colors
Modify CSS variables in `style.css`:

```css
:root {
    --primary-color: #your-color;
    --secondary-color: #your-color;
    /* ... other variables */
}
```

### Adjusting Scoring
Modify the `calculateScore()` function in `script.js` to change severity thresholds or add new categories.

## 🔧 Browser Compatibility

- **Modern Browsers**: Chrome 70+, Firefox 65+, Safari 12+, Edge 79+
- **Mobile**: iOS Safari 12+, Chrome Mobile 70+
- **Features**: Uses vanilla JavaScript (no frameworks required)
- **Fallbacks**: Graceful degradation for older browsers

## 📱 Mobile Optimization

- **Responsive Design**: Optimized for screens from 320px to 4K
- **Touch-Friendly**: Large tap targets and intuitive gestures
- **Performance**: Fast loading with optimized assets
- **Accessibility**: Screen reader compatible and keyboard navigable

## 🔒 Privacy & Data Handling

- **Local Processing**: All calculations happen in the user's browser
- **No Data Transmission**: No information sent to external servers
- **No Tracking**: No analytics or user behavior monitoring
- **Export Control**: Users can download their results locally

## 📈 Research Foundation

This assessment is based on workplace communication research including:

- **Email Overload Studies**: Research showing average workers receive 121+ emails daily
- **Attention Fragmentation**: Studies on interruption costs (23 minutes to refocus)
- **Digital Wellbeing**: Research on technostress and communication burnout
- **Productivity Impact**: Studies measuring communication effects on task completion

## 🤝 Contributing

Want to improve the assessment tool? Consider:

- **Additional Questions**: Suggest research-backed communication overload indicators
- **Accessibility**: Report or fix accessibility issues
- **Translations**: Help make the tool available in other languages
- **Research**: Share relevant studies to improve question validity

## 📄 License

This project is open source and available under the MIT License. Feel free to use, modify, and distribute for personal or commercial purposes.

## 🆘 Support & Issues

### Common Issues

**GitHub Pages not updating?**
- Check repository settings → Pages section
- Ensure source is set to "main" branch
- Wait 5-10 minutes for deployment

**Assessment not working?**
- Ensure all 4 files are uploaded
- Check browser console for JavaScript errors
- Verify files are in the repository root (not in a subfolder)

**Mobile display issues?**
- Clear browser cache
- Test in incognito/private mode
- Ensure viewport meta tag is present in HTML

### Getting Help

1. Check this README for troubleshooting steps
2. Review browser console for error messages
3. Test the tool locally by opening `index.html` in a browser
4. Verify all files are uploaded to your GitHub repository

## 🌟 Acknowledgments

Built with modern web standards and inspired by research in:
- Digital Wellbeing and Workplace Psychology
- Human-Computer Interaction
- Organizational Communication Studies
- User Experience Design

---

**Ready to deploy?** Upload these files to your GitHub repository and enable GitHub Pages to make your communication overload assessment tool available worldwide! 🚀