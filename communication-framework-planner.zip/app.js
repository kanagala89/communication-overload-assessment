// Communication Overload Framework Application JavaScript

// Application State
let appState = {
    currentSection: 'dashboard',
    assessmentScores: {},
    organizationData: {},
    taskProgress: {}
};

// Framework data from the provided JSON
const frameworkData = {
    "framework_phases": [
        {
            "id": 1,
            "name": "Assessment & Diagnosis",
            "duration": "4 weeks",
            "tasks": [
                "Complete communication audit",
                "Create channel inventory", 
                "Conduct employee survey",
                "Perform cost analysis"
            ],
            "deliverables": ["Communication landscape report", "Current state assessment", "Cost baseline"]
        },
        {
            "id": 2, 
            "name": "Strategic Planning",
            "duration": "4 weeks",
            "tasks": [
                "Establish governance structure",
                "Create communication charter",
                "Develop channel strategy", 
                "Build change management plan"
            ],
            "deliverables": ["Governance model", "Communication policies", "Implementation roadmap"]
        },
        {
            "id": 3,
            "name": "Implementation", 
            "duration": "8 weeks",
            "tasks": [
                "Launch pilot programs",
                "Deploy training & education",
                "Implement policies",
                "Enable leadership modeling"
            ],
            "deliverables": ["Pilot results", "Training completion", "Policy adoption"]
        },
        {
            "id": 4,
            "name": "Technology & Tools",
            "duration": "8 weeks", 
            "tasks": [
                "Consolidate platforms",
                "Implement notification management",
                "Deploy automation tools",
                "Setup analytics systems"
            ],
            "deliverables": ["Reduced platform count", "Automation deployment", "Analytics dashboard"]
        },
        {
            "id": 5,
            "name": "Measurement & Optimization",
            "duration": "Ongoing",
            "tasks": [
                "Track KPIs",
                "Collect employee feedback", 
                "Analyze performance",
                "Drive continuous improvement"
            ],
            "deliverables": ["Performance dashboards", "Improvement recommendations", "ROI reports"]
        }
    ],
    "assessment_questions": [
        {
            "category": "Volume",
            "question": "How many emails does the average employee receive per day?",
            "benchmark": 121,
            "options": ["<50", "50-100", "100-150", "150+"]
        },
        {
            "category": "Platforms", 
            "question": "How many communication platforms does your organization actively use?",
            "benchmark": 8,
            "options": ["1-3", "4-6", "7-10", "10+"]
        },
        {
            "category": "Time",
            "question": "What percentage of work time do employees spend on communication?",
            "benchmark": 88,
            "options": ["<50%", "50-70%", "70-90%", "90%+"]
        },
        {
            "category": "Satisfaction",
            "question": "How satisfied are employees with current communication effectiveness?",
            "benchmark": 6.2,
            "options": ["Very dissatisfied", "Dissatisfied", "Neutral", "Satisfied", "Very satisfied"]
        }
    ]
};

// Initialize application
document.addEventListener('DOMContentLoaded', function() {
    initializeNavigation();
    initializeTaskTracking();
    loadSavedData();
});

// Navigation functionality
function initializeNavigation() {
    const navButtons = document.querySelectorAll('.nav-btn');
    
    navButtons.forEach(button => {
        button.addEventListener('click', function() {
            const targetSection = this.getAttribute('data-section');
            switchSection(targetSection);
        });
    });
}

function switchSection(sectionId) {
    // Hide all sections
    const sections = document.querySelectorAll('.content-section');
    sections.forEach(section => {
        section.classList.remove('active');
    });
    
    // Show target section
    const targetSection = document.getElementById(sectionId);
    if (targetSection) {
        targetSection.classList.add('active');
    }
    
    // Update navigation
    const navButtons = document.querySelectorAll('.nav-btn');
    navButtons.forEach(button => {
        button.classList.remove('active');
    });
    
    const activeButton = document.querySelector(`[data-section="${sectionId}"]`);
    if (activeButton) {
        activeButton.classList.add('active');
    }
    
    appState.currentSection = sectionId;
    saveData();
}

// Assessment functionality
function calculateAssessmentScore() {
    const questions = document.querySelectorAll('[data-question]');
    let totalScore = 0;
    let answeredQuestions = 0;
    
    questions.forEach(question => {
        const value = question.value;
        if (value) {
            const questionType = question.getAttribute('data-question');
            const score = parseInt(value);
            appState.assessmentScores[questionType] = score;
            totalScore += score;
            answeredQuestions++;
        }
    });
    
    if (answeredQuestions === 0) {
        alert('Please answer at least one question to calculate your assessment score.');
        return;
    }
    
    const averageScore = totalScore / answeredQuestions;
    const maxScore = 5; // Assuming 5-point scale for most questions
    const percentageScore = (averageScore / maxScore) * 100;
    
    let riskLevel = '';
    let recommendations = '';
    
    if (percentageScore >= 80) {
        riskLevel = 'High Risk';
        recommendations = 'Immediate action required. Your organization shows signs of severe communication overload.';
    } else if (percentageScore >= 60) {
        riskLevel = 'Moderate Risk';
        recommendations = 'Significant improvements needed. Consider implementing framework phases 1-3 immediately.';
    } else if (percentageScore >= 40) {
        riskLevel = 'Low-Moderate Risk';
        recommendations = 'Some areas for improvement. Focus on strategic planning and optimization.';
    } else {
        riskLevel = 'Low Risk';
        recommendations = 'Good foundation. Focus on continuous improvement and measurement.';
    }
    
    const resultDiv = document.getElementById('assessmentResult');
    resultDiv.innerHTML = `
        <h4>Assessment Results</h4>
        <div class="result-summary">
            <p><strong>Overall Score:</strong> ${percentageScore.toFixed(1)}%</p>
            <p><strong>Risk Level:</strong> <span class="status status--${riskLevel.toLowerCase().includes('high') ? 'error' : riskLevel.toLowerCase().includes('moderate') ? 'warning' : 'success'}">${riskLevel}</span></p>
            <p><strong>Recommendations:</strong> ${recommendations}</p>
        </div>
        <div class="next-steps">
            <h5>Next Steps:</h5>
            <ul>
                <li>Proceed to the Planning Workspace to develop your strategy</li>
                <li>Use the ROI Calculator to estimate potential savings</li>
                <li>Review the Resource Center for implementation guidance</li>
            </ul>
        </div>
    `;
    resultDiv.classList.remove('hidden');
    
    saveData();
}

// Cost calculator functionality
function calculateCurrentCost() {
    const orgSize = parseInt(document.getElementById('orgSize').value) || 500;
    const hourlyRate = parseFloat(document.getElementById('hourlyRate').value) || 50;
    const commHours = parseInt(document.getElementById('commHours').value) || 35;
    const numPlatforms = parseInt(document.getElementById('numPlatforms').value) || 12;
    
    // Store organization data
    appState.organizationData = {
        orgSize,
        hourlyRate,
        commHours,
        numPlatforms
    };
    
    // Calculate current costs
    const weeklyCommCost = orgSize * commHours * hourlyRate;
    const annualCommCost = weeklyCommCost * 52;
    const platformCostPerEmployee = numPlatforms * 15; // Estimated $15 per platform per employee
    const annualPlatformCost = orgSize * platformCostPerEmployee * 12;
    const totalAnnualCost = annualCommCost + annualPlatformCost;
    
    // Calculate inefficiency costs (assuming 30% inefficiency)
    const inefficiencyCost = totalAnnualCost * 0.3;
    
    const resultDiv = document.getElementById('costResult');
    resultDiv.innerHTML = `
        <h4>Current State Cost Analysis</h4>
        <div class="cost-breakdown">
            <div class="cost-item">
                <span>Annual Communication Time Cost:</span>
                <span><strong>$${annualCommCost.toLocaleString()}</strong></span>
            </div>
            <div class="cost-item">
                <span>Annual Platform Licensing:</span>
                <span><strong>$${annualPlatformCost.toLocaleString()}</strong></span>
            </div>
            <div class="cost-item">
                <span>Estimated Inefficiency Cost:</span>
                <span><strong>$${inefficiencyCost.toLocaleString()}</strong></span>
            </div>
            <div class="cost-total">
                <span>Total Annual Impact:</span>
                <span><strong>$${totalAnnualCost.toLocaleString()}</strong></span>
            </div>
        </div>
        <div class="cost-insights">
            <h5>Key Insights:</h5>
            <ul>
                <li>Employees spend ${((commHours / 40) * 100).toFixed(0)}% of their work time on communication</li>
                <li>Average cost per employee: $${(totalAnnualCost / orgSize).toLocaleString()}</li>
                <li>Platform overhead: ${numPlatforms} active platforms</li>
            </ul>
        </div>
    `;
    resultDiv.classList.remove('hidden');
    
    saveData();
}

// ROI Calculator functionality
function calculateROI() {
    const orgSize = parseInt(document.getElementById('roiOrgSize').value) || 500;
    const hourlyRate = parseFloat(document.getElementById('roiHourlyRate').value) || 50;
    const commHours = parseInt(document.getElementById('roiCommHours').value) || 35;
    const numPlatforms = parseInt(document.getElementById('roiPlatforms').value) || 12;
    
    // Calculate current state
    const currentWeeklyCost = orgSize * commHours * hourlyRate;
    const currentAnnualCost = currentWeeklyCost * 52;
    
    // Calculate improved state (framework benefits)
    const improvedCommHours = Math.max(commHours * 0.6, 20); // 40% reduction, minimum 20 hours
    const improvedPlatforms = Math.max(Math.ceil(numPlatforms * 0.4), 3); // 60% reduction, minimum 3
    const improvedWeeklyCost = orgSize * improvedCommHours * hourlyRate;
    const improvedAnnualCost = improvedWeeklyCost * 52;
    
    // Calculate savings
    const annualTimeSavings = (commHours - improvedCommHours) * orgSize * 52;
    const annualCostSavings = currentAnnualCost - improvedAnnualCost;
    const platformSavings = numPlatforms - improvedPlatforms;
    const platformCostSavings = platformSavings * orgSize * 15 * 12; // $15/platform/employee/month
    
    const totalAnnualSavings = annualCostSavings + platformCostSavings;
    const implementationCost = orgSize * 250; // Estimated $250 per employee implementation cost
    const threeYearSavings = (totalAnnualSavings * 3) - implementationCost;
    const roiPercentage = ((threeYearSavings / implementationCost) * 100);
    
    // Update results display
    document.getElementById('timeSavings').textContent = `${annualTimeSavings.toLocaleString()} hours`;
    document.getElementById('costSavings').textContent = `$${totalAnnualSavings.toLocaleString()}`;
    document.getElementById('platformSavings').textContent = `${platformSavings} platforms`;
    document.getElementById('totalROI').textContent = `${roiPercentage.toFixed(0)}%`;
    
    // Show results section
    document.getElementById('roiResults').classList.remove('hidden');
    
    saveData();
}

// Task tracking functionality
function initializeTaskTracking() {
    const checkboxes = document.querySelectorAll('.task-item input[type="checkbox"]');
    
    checkboxes.forEach(checkbox => {
        checkbox.addEventListener('change', function() {
            const taskId = this.id;
            const isChecked = this.checked;
            
            appState.taskProgress[taskId] = isChecked;
            updatePhaseProgress();
            saveData();
        });
    });
}

function updatePhaseProgress() {
    const phases = document.querySelectorAll('.phase-card');
    
    phases.forEach(phase => {
        const phaseId = phase.getAttribute('data-phase');
        const checkboxes = phase.querySelectorAll('input[type="checkbox"]');
        const checkedBoxes = phase.querySelectorAll('input[type="checkbox"]:checked');
        
        const progress = checkboxes.length > 0 ? (checkedBoxes.length / checkboxes.length) * 100 : 0;
        
        const progressBar = phase.querySelector('.progress-fill');
        const progressText = phase.querySelector('.progress-text');
        
        if (progressBar) {
            progressBar.style.width = `${progress}%`;
        }
        
        if (progressText) {
            progressText.textContent = `${Math.round(progress)}% Complete`;
        }
        
        // Update phase status
        if (progress === 100) {
            phase.classList.remove('active');
            phase.classList.add('completed');
        } else if (progress > 0) {
            phase.classList.add('active');
            phase.classList.remove('completed');
        }
    });
}

// Data persistence functions
function saveData() {
    try {
        // Note: Using a simple object to simulate data persistence within the session
        // In a real application, this would be saved to a backend or localStorage
        window.appSessionData = {
            state: appState,
            timestamp: new Date().toISOString()
        };
    } catch (error) {
        console.warn('Unable to save data:', error);
    }
}

function loadSavedData() {
    try {
        if (window.appSessionData) {
            const savedState = window.appSessionData.state;
            
            // Restore task progress
            if (savedState.taskProgress) {
                Object.keys(savedState.taskProgress).forEach(taskId => {
                    const checkbox = document.getElementById(taskId);
                    if (checkbox) {
                        checkbox.checked = savedState.taskProgress[taskId];
                    }
                });
                appState.taskProgress = savedState.taskProgress;
                updatePhaseProgress();
            }
            
            // Restore other state
            if (savedState.assessmentScores) {
                appState.assessmentScores = savedState.assessmentScores;
            }
            
            if (savedState.organizationData) {
                appState.organizationData = savedState.organizationData;
                // Restore form values
                const fields = ['orgSize', 'hourlyRate', 'commHours', 'numPlatforms'];
                fields.forEach(field => {
                    const element = document.getElementById(field);
                    if (element && savedState.organizationData[field]) {
                        element.value = savedState.organizationData[field];
                    }
                });
            }
        }
    } catch (error) {
        console.warn('Unable to load saved data:', error);
    }
}

// Form validation helper
function validateForm(formSelector) {
    const form = document.querySelector(formSelector);
    if (!form) return false;
    
    const requiredFields = form.querySelectorAll('[required]');
    let isValid = true;
    
    requiredFields.forEach(field => {
        if (!field.value.trim()) {
            isValid = false;
            field.style.borderColor = 'var(--color-error)';
        } else {
            field.style.borderColor = '';
        }
    });
    
    return isValid;
}

// Utility functions
function formatCurrency(amount) {
    return new Intl.NumberFormat('en-US', {
        style: 'currency',
        currency: 'USD',
        minimumFractionDigits: 0,
        maximumFractionDigits: 0
    }).format(amount);
}

function formatNumber(number) {
    return new Intl.NumberFormat('en-US').format(number);
}

// Template download functionality (simulated)
document.addEventListener('click', function(e) {
    if (e.target.textContent === 'Download' && e.target.classList.contains('btn')) {
        e.preventDefault();
        
        const templateItem = e.target.closest('.template-item');
        const templateName = templateItem.querySelector('h4').textContent;
        
        // Simulate download
        const blob = new Blob([`# ${templateName}\n\nThis is a template for ${templateName}. In a real application, this would contain the actual template content.`], {
            type: 'text/markdown'
        });
        
        const url = URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = `${templateName.toLowerCase().replace(/\s+/g, '-')}.md`;
        document.body.appendChild(a);
        a.click();
        document.body.removeChild(a);
        URL.revokeObjectURL(url);
        
        // Show feedback
        const originalText = e.target.textContent;
        e.target.textContent = 'Downloaded!';
        e.target.style.backgroundColor = 'var(--color-success)';
        e.target.style.color = 'white';
        
        setTimeout(() => {
            e.target.textContent = originalText;
            e.target.style.backgroundColor = '';
            e.target.style.color = '';
        }, 2000);
    }
});

// Auto-save functionality for forms
document.addEventListener('input', function(e) {
    if (e.target.matches('.form-control')) {
        // Debounce auto-save
        clearTimeout(window.autoSaveTimer);
        window.autoSaveTimer = setTimeout(() => {
            saveData();
        }, 1000);
    }
});

// Initialize dashboard metrics animation
function animateMetrics() {
    const progressBars = document.querySelectorAll('.metric-card .progress-fill');
    
    progressBars.forEach((bar, index) => {
        setTimeout(() => {
            bar.style.transform = 'scaleX(1)';
        }, index * 200);
    });
}

// Call animation after page load
window.addEventListener('load', function() {
    setTimeout(animateMetrics, 500);
});

// Keyboard navigation support
document.addEventListener('keydown', function(e) {
    if (e.ctrlKey || e.metaKey) {
        switch(e.key) {
            case '1':
                e.preventDefault();
                switchSection('dashboard');
                break;
            case '2':
                e.preventDefault();
                switchSection('assessment');
                break;
            case '3':
                e.preventDefault();
                switchSection('planning');
                break;
            case '4':
                e.preventDefault();
                switchSection('implementation');
                break;
            case '5':
                e.preventDefault();
                switchSection('roi');
                break;
            case '6':
                e.preventDefault();
                switchSection('resources');
                break;
        }
    }
});

// Expose global functions for HTML onclick handlers
window.calculateAssessmentScore = calculateAssessmentScore;
window.calculateCurrentCost = calculateCurrentCost;
window.calculateROI = calculateROI;